//#3 More buttons
//Next Button implementation

function Next ({ performNext}){
    console.log(performNext)
    return<button onClick={performNext}>Next</button>

}
export default Next;
