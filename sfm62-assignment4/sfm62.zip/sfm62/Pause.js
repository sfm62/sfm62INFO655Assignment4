//#3 More buttons
//Next Button implementation
function PlayPause ({ performPlayPause }){
    
    return<button onClick={performPlayPause}>Play/Pause</button>

}
export default PlayPause;