//#3 More buttons
//Next Button implementation
function Previous ({ performPrevious }){
    return<button onClick={performPrevious}>Previous</button>

}
export default Previous;