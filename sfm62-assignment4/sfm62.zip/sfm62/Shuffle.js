//Shuffle without reloading 
//#3 More buttons
function Shuffle ({ performShuffle }){
    return <button onClick={performShuffle}>Shuffle</button>;
}
export default Shuffle;



